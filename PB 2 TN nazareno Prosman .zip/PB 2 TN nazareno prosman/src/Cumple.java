
public class Cumple {
	 Agasajado agasajado;

	public Cumple(Agasajado agasajado) {
		this.agasajado = agasajado;
	}

	public Agasajado getAgasajado() {
		return agasajado;
	}
}