
public class Casamiento {

}
