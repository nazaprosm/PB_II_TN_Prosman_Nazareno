
public class Evento {
String nombre;
String organizador;
public String getOrganizador() {
	return organizador;
}

public void setOrganizador(String organizador) {
	this.organizador = organizador;
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}



}