
public class Usuario {
    

    private String mailAgasajado;
	private String nombreAgasajado;
	private int edadAgasajado;


	public Usuario(String mailAgasajado, String nombreAgasajado, int edadAgasajado) {
        this.mailAgasajado = mailAgasajado;
        this.nombreAgasajado = nombreAgasajado;
        this.edadAgasajado = edadAgasajado;}
	
	public String getMailOrganizador() {
		return mailOrganizador;
	}


	public void setMailOrganizador(String mailOrganizador) {
		this.mailOrganizador = mailOrganizador;
	}


	public String getNombreOrganizador() {
		return nombreOrganizador;
	}


	public void setNombreOrganizador(String nombreOrganizador) {
		this.nombreOrganizador = nombreOrganizador;
	}


	public Integer getEdadOrganizador() {
		return edadOrganizador;
	}


	public void setEdadOrganizador(Integer edadOrganizador) {
		this.edadOrganizador = edadOrganizador;
	}


	String mailOrganizador;
	String nombreOrganizador;
	Integer edadOrganizador;
	
	
	public Usuario(String mailOrganizador, String nombreOrganizador, Integer edadOrganizador) {
		// TODO Auto-generated constructor stub
	}
	

	

}
