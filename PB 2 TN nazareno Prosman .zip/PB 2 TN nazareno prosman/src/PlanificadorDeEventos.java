import java.util.ArrayList;

public class PlanificadorDeEventos {
	
    ArrayList<Usuario> listaUsuarios = new ArrayList<>();
    ArrayList<Evento> cantidadEventos = new ArrayList<>();
    ArrayList<Cumpleanios> cantidadCumpleanios = new ArrayList<>();
    ArrayList<Casamiento> CantidadDeCasamientos = new ArrayList<>();
    
    
    public PlanificadorDeEventos() {
        listaUsuarios = new ArrayList<>();
    }

    public void add(Usuario usuario) {
        listaUsuarios.add(usuario);
    }
 
    
    
    
    
    
    public void crear(Usuario organizador, Evento cumple) {
    	cantidadEventos.add(cumple);
   
    }

	public ArrayList<Usuario> getListaUsuarios() {
		return listaUsuarios;
	}

	public void setListaUsuarios(ArrayList<Usuario> listaUsuarios) {
		this.listaUsuarios = listaUsuarios;
	}

	 public int getCantidadDeUsuarios() {
	        return listaUsuarios.size(); 
	    }
	 
	  public int getCantidadDeCasamientos() {
	        return CantidadDeCasamientos.size(); 
	    }
	
	 
	 public int getCantidadDeEventos() {
	        return cantidadEventos.size(); 
	    }
	public int getCantidadCumpleanios() {
        return cantidadCumpleanios.size(); 
    }

	public Usuario getUsuario(String mailOrganizador) {
		// TODO Auto-generated method stub
		return null;
	}

	 public Evento getEvento(String nombreEvento) {
        for (Evento evento : cantidadEventos) {
            if (evento.getNombre().equals(nombreEvento)) {
                return evento; 
            }
        }
        return null; 
        }

	public ArrayList<Evento> getCantidadEventos() {
		return cantidadEventos;
	}

	public void setCantidadEventos(ArrayList<Evento> cantidadEventos) {
		this.cantidadEventos = cantidadEventos;
	}

	public void setCantidadCumpleanios(ArrayList<Cumpleanios> cantidadCumpleanios) {
		this.cantidadCumpleanios = cantidadCumpleanios;
	}

	public void crear(Evento usuario) {
		cantidadEventos.add(usuario);
		
	}

	public void crear(Usuario usuario, Cumple cumple) {
		// TODO Auto-generated method stub
		
	}


}


	


    
