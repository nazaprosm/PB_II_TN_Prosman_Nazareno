
public class Agasajado {

	private String mailAgasajado;
    private String nombreAgasajado;
    private int edadAgasajado;
	public String getMailAgasajado() {
		return mailAgasajado;
	}
	public void setMailAgasajado(String mailAgasajado) {
		this.mailAgasajado = mailAgasajado;
	}
	public String getNombreAgasajado() {
		return nombreAgasajado;
	}
	public void setNombreAgasajado(String nombreAgasajado) {
		this.nombreAgasajado = nombreAgasajado;
	}
	public int getEdadAgasajado() {
		return edadAgasajado;
	}
	public void setEdadAgasajado(int edadAgasajado) {
		this.edadAgasajado = edadAgasajado;
	}
	
	
}
